import React from 'react'
import '../App.css'

const MainPage = () => {
  return (
    <div className='container'>
        <h2>메인요리</h2>
    </div>
  )
}

export default MainPage