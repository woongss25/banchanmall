import React from 'react'
import '../App.css'

const ProductDetailPage = () => {
  return (
    <div className='container'>
        <h2>상품상세페이지</h2>
    </div>
  )
}

export default ProductDetailPage