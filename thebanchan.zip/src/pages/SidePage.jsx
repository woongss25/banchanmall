import React from 'react'
import '../App.css'

const SidePage = () => {
  return (
    <div className='container'>
        <h2>밑반찬</h2>
    </div>
  )
}

export default SidePage