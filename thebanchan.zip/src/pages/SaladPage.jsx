import React from 'react'
import '../App.css'

const SaladPage = () => {
    return (
        <div className='container'>
            <h2>샐러드</h2>
        </div>
    )
}

export default SaladPage