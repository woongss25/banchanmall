import React from 'react'
import '../App.css'

const SoupPage = () => {
  return (
    <div className='container'>
    <h2>국 &middot; 탕 &middot; 찌개</h2>
</div>
  )
}

export default SoupPage