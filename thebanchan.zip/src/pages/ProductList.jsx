import React from 'react'
import '../App.css'

const ProductList = () => {
  return (
    <div className='container'>
        <h2>전체 상품</h2>
    </div>
  )
}

export default ProductList